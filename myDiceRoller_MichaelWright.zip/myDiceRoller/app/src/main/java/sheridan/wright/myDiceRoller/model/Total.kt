package sheridan.wright.myDiceRoller.model

class Total(){
    //default value for total
    var total: Int = 0
}